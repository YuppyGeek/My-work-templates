// Wait for the DOM to fully load
document.addEventListener("DOMContentLoaded", () => {
    // Smooth Scrolling for Navigation Links
    const navLinks = document.querySelectorAll(".nav-links a");

    navLinks.forEach(link => {
        link.addEventListener("click", (e) => {
            e.preventDefault();
            const targetId = e.target.getAttribute("href").substring(1);
            const targetElement = document.getElementById(targetId);

            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 50, // Adjust for fixed header height
                    behavior: "smooth"
                });
            }
        });
    });

    // Responsive Navigation Toggle
    const navToggle = document.createElement("button");
    navToggle.textContent = "☰";
    navToggle.classList.add("nav-toggle");
    document.querySelector("header .navbar").appendChild(navToggle);

    const navMenu = document.querySelector(".nav-links");
    navToggle.addEventListener("click", () => {
        navMenu.classList.toggle("active");
    });

    // Form Validation
    const contactForm = document.querySelector("form");
    if (contactForm) {
        contactForm.addEventListener("submit", (e) => {
            e.preventDefault();

            const formData = new FormData(contactForm);
            const name = formData.get("name");
            const email = formData.get("email");
            const message = formData.get("message");

            let errors = [];

            if (!name.trim()) errors.push("Name is required.");
            if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                errors.push("Valid email is required.");
            }
            if (!message.trim()) errors.push("Message cannot be empty.");

            if (errors.length) {
                alert(errors.join("\n"));
            } else {
                alert("Thank you for your message! We will get back to you soon.");
                contactForm.reset();
            }
        });
    }
});
